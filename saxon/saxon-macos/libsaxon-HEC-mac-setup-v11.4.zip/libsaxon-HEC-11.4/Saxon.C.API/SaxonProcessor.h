////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2022 Saxonica Limited.
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef SAXON_PROCESSOR_H
#define SAXON_PROCESSOR_H


#if defined __linux__ || defined __APPLE__

#include <stdlib.h>
#include <string>
#include <dlfcn.h>

#define HANDLE void*
#define LoadLibrary(x) dlopen(x, RTLD_LAZY)
#define GetProcAddress(x, y) dlsym(x,y)
#else
#include <windows.h>
#endif

//#define DEBUG //remove
//#define MEM_DEBUG //remove
#define CVERSION "11.4"
#define CVERSION_API_NO 1140




#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <vector>
#include <stdexcept>      // std::logic_error

#include "SaxonCGlue.h"
#include "SaxonCXPath.h"
#include "Xslt30Processor.h"
#include "XsltExecutable.h"
#include "DocumentBuilder.h"
#include "XQueryProcessor.h"
#include "XPathProcessor.h"
#include "SchemaValidator.h"
#include "SaxonApiException.h"
//#include "com_saxonica_functions_extfn_PhpCall.h"
//#include "com_saxonica_functions_extfn_PhpCall_PhpFunctionCall.h"
//#define MEM_DEBUG
#if defined MEM_DEBUG


#include <algorithm>
#include <cstdlib>
#include <new>

static std::vector<void*> myAlloc;

void* newImpl(std::size_t sz,char const* file, int line);

void* operator new(std::size_t sz,char const* file, int line);

void* operator new [](std::size_t sz,char const* file, int line);

void operator delete(void* ptr) noexcept;

void operator delete(void*, std::size_t) noexcept;

#endif


class Xslt30Processor;

class XQueryProcessor;

class XPathProcessor;

class SchemaValidator;

class XdmValue;

class XdmNode;

class XdmItem;

class XdmAtomicValue;

class XdmFunctionItem;

class XdmArray;

class XdmMap;

class XsltExecutable;

class DocumentBuilder;

class SaxonApiException;


//! A struct object to represent parameters.
/*! Internal use only. This struct represents parameters to pass back the Java code. These two arrays acts as a map to represent the parameters. */
typedef struct {
    jobjectArray stringArray; /*!< Internal use only. Java array of String objects. */
    jobjectArray objectArray; /*!< Internal use only. Java Array of objects. The underlying type can be different. */

} JParameters;



//==========================================


//! The <code>SaxonProcessor</code> class acts as a factory for generating XQuery, XPath, Schema and XSLT compilers
/*! The <code>SaxonProcessor</code> class not only generates XQuery, XPath, Schema and XSLT Processors, but is used to create Xdm objects from primitive types.
 */
class SaxonProcessor {

    friend class DocumentBuilder;

    friend class Xslt30Processor;

    friend class XsltExecutable;

    friend class XQueryProcessor;

    friend class SchemaValidator;

    friend class XPathProcessor;

    friend class XdmValue;

    friend class XdmAtomicValue;

    friend class XdmFunctionItem;

    friend class XdmNode;

    friend class XdmMap;

    friend class XdmArray;

public:

    //! A default constructor.
    /*!
      * Create Saxon Processor.
    */

    SaxonProcessor();

    //! constructor based upon a Saxon configuration file.
    /*!
      * Create Saxon Processor.
    */

    SaxonProcessor(const char *configFile);


    //! A constructor.
    /*!
      * Create Saxon Processor.
      * @param l - Flag that a license is to be used. Default is false.	
    */
    SaxonProcessor(bool l);

    //! The copy assignment= operator
    /*!
      * Create a copy of the Saxon Processor.
      * @param other - SaxonProcessor object
    */
    SaxonProcessor &operator=(const SaxonProcessor &other);


    //! SaxonProcessor copy constructor.
    /**
     *
     * @param other - SaxonProcessor
     */
    SaxonProcessor(const SaxonProcessor &other);

    //! Destructor method. At the end of the program call the release() method to clear the JVM.
    ~SaxonProcessor();

    //! Get any error message thrown by the processor
    /*!
      * @return string value of the error message. JNI exceptions thrown by this
      * processor are handled internally and can be retrived by this method.
    */
    const char * getErrorMessage();

    //! Create a DocumentBuilder.
    /**
     * A DocumentBuilder is used to load source XML documents.
     *
     * @return a newly created DocumentBuilder
     */
    DocumentBuilder * newDocumentBuilder();


    //! Create an Xslt30Processor.
    /*!
       * An Xslt30Processor is used to compile XSLT30 stylesheets.
       * @return a newly created Xslt30Processor
     */
    Xslt30Processor *newXslt30Processor();


    //! Create an XQueryProcessor.
    /*!
     * An XQueryProcessor is used to compile XQuery queries.
     *
     * @return a newly created XQueryProcessor
     */
    XQueryProcessor *newXQueryProcessor();


    //! Create an XPathProcessor. An XPathProcessor is used to compile XPath expressions.
    /*!
     *
     *
     * @return a newly created XPathProcessor
     */
    XPathProcessor *newXPathProcessor();

    //! Create a SchemaValidator which can be used to validate instance documents against the schema held by this SchemaManager
    /**
     *
     *
     * @return a new SchemaValidator
     */
    SchemaValidator *newSchemaValidator();

    //! Factory method. Unlike the constructor, this avoids creating a new StringValue in the case
    /*!
     *
     * of a zero-length string (and potentially other strings, in future)
     *
     * @param value the String value. NULL is taken as equivalent to "".
     * @return the corresponding StringValue
     */
    XdmAtomicValue *makeStringValue(std::string str);

    //! Factory method. Unlike the constructor, this avoids creating a new StringValue in the case
    /*!
     *
     * of a zero-length string (and potentially other strings, in future)
     *
     * @param value the char pointer array. nullptr is taken as equivalent to "".
     * @return the corresponding StringValue
     */
    XdmAtomicValue *makeStringValue(const char *str);

    //! Factory method. Unlike the constructor, this avoids creating a new StringValue in the case
    /*!
     *
     * of a zero-length string (and potentially other strings, in future)
     *
     * @param value the std:string
     * @return the corresponding StringValue
     */
    static XdmAtomicValue *makeStringValue2(std::string str);

    /*!
     * Factory method: makes either an Int64Value or a BigIntegerValue depending on the value supplied
     *
     * @param i the supplied primitive integer value
     * @return the value as a XdmAtomicValue which is a BigIntegerValue or Int64Value as appropriate
     */
    XdmAtomicValue *makeIntegerValue(int i);


    //! Factory method. make an XdmAtomicValue from a primitive double value
    /*!
     *
     * @param d the value of the double
     * @return a new XdmAtomicValue
     */
    XdmAtomicValue *makeDoubleValue(double d);

    //! Factory method. make an XdmAtomicValue from a primitive float value
    /*!
     *
     *
     * @param f the value of the foat
     * @return a new XdmAtomicValue
     */
    XdmAtomicValue *makeFloatValue(float);

    //! Factory method: makes either an Int64Value or a BigIntegerValue depending on the value supplied
    /*!
     *
     *
     * @param l the supplied primitive long value
     * @return the value as a XdmAtomicValue which is a BigIntegerValue or Int64Value as appropriate
     */
    XdmAtomicValue *makeLongValue(long l);

    //! Factory method: makes a XdmAtomicValue representing a boolean Value
    /*!
     *
     *
     * @param b true or false, to determine which boolean value is
     *              required
     * @return the XdmAtomicValue requested
     */
    XdmAtomicValue *makeBooleanValue(bool b);

    //! Create an QName Xdm value from string representation in clark notation
    /**
     *
     * @param str - The value given in a string form in clark notation. {uri}local
     * @return XdmAtomicValue - value
    */
    XdmAtomicValue *makeQNameValue(const char *str);

    //! Create an Xdm Atomic value from string representation
    /*!
     *
     * @param type    - Local name of a type in the XML Schema namespace.
     * @param value - The value given in a string form.
     * In the case of a QName the value supplied must be in clark notation. {uri}local
     * @return XdmValue - value
    */
    XdmAtomicValue *makeAtomicValue(const char *type, const char *value);

    //! Make an XdmArray whose members are from string representation
    /**
        *
        * @param input the input array of booleans
        * @param length - the number of items in the array
        * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
    XdmArray *makeArray(const char **input, int length);


    //! Make an XdmArray whose members are xs:short values
    /**
        *
        * @param input  - the input array of short values
        * @param length - the number of items in the array
        * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
    XdmArray *makeArray(short *input, int length);


    //! Make an XdmArray whose members are xs:int values
    /**
        *
        * @param input  - the input array of int values
        * @param length - the number of items in the array
        * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
    XdmArray *makeArray(int *input, int length);

    //! Make an XdmArray whose members are xs:long values
    /**
        *
        * @param input  - the input array of long values
        * @param length - the number of items in the array
        * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
    XdmArray *makeArray(long *input, int length);

    /**
        * Make an XdmArray whose members are xs:boolean values
        * @param input  - the input array of boolean values
        * @param length - the number of items in the array
        * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
    XdmArray *makeArray(bool *input, int length);


    //! Make an XdmArray whose members are of type XdmValue
    /**
        *
        * @param input the input array of XdmValue pointers
        * @param length - the number of items in the array
        * @return an XdmArray whose members are XdmValue values corresponding one-to-one with the input
   */
    XdmArray *makeArray(XdmValue ** values, int length);

    //! Make an XdmMap whose argument is a map from the standard template library.
    /**
        *
        * @param dataMap  is std::map, which consists of keys as XdmAtomicValue and value is XdmValue.
        * @return an XdmMap whose members are key, value pair given as (XdmAtomicValue, XdmValue)
   */
    XdmMap *makeMap(std::map<XdmAtomicValue *, XdmValue *> dataMap);

    //! Make an XdmMap whose argument is a map from the standard template library.
    /**
        *
        * @param dataMap  is std::map, which consists of keys as std::string and value is XdmValue. Keys are converted to XdmAtomicValue objects
        * @return an XdmMap whose members are key, value pair given as (XdmAtomicValue, XdmValue)
   */
    static XdmMap *makeMap2(std::map<std::string, XdmValue *> dataMap);

    //! Make an XdmMap from an array of keys and values.
    /**
        *
        * @param keys - The keys are given as a pointer array of XdmAtomicValue
        * @param values - The values are given as a pointer array of XdmValue
        * @param len - The length of the arrays given as argument
        * @return an XdmMap whose members are key, value pair given as (XdmAtomicValue, XdmValue)
   */
    XdmMap *makeMap3(XdmAtomicValue ** keys, XdmValue ** values, int len);


    //! Get the string representation of the XdmValue.
    /**
    * @param item - The XdmItem
    * @return string value as char array
    */
    const char *getStringValue(XdmItem *item);

    //! Parse a lexical representation of the source document and return it as an XdmNode
    /**
     *
     * @param source
     * @param validator
     * @return an XdmNode
    */
    XdmNode *parseXmlFromString(const char *source, SchemaValidator * validator = nullptr);

    //! Parse a source document file and return it as an XdmNode.
    /**
     *
     @param validator.
     @return an XdmNode
    */
    XdmNode *parseXmlFromFile(const char *source, SchemaValidator * validator = nullptr);

    //! Parse a source document available by URI and return it as an XdmNode.
    /**
     *
     @param validator.
     @return an XdmNode
    */
    XdmNode *parseXmlFromUri(const char *source, SchemaValidator * validator = nullptr);

    //! Get the kind of node.
    /**
     *
     * @param obj - The Java object representation of the XdmNode
     * @return the kind of node, for example ELEMENT or ATTRIBUTE
     */
    int getNodeKind(jobject obj);

    //! Test whether this processor is schema-aware
    /**
     *
     * @return true if this this processor is licensed for schema processing, false otherwise
     */
    bool isSchemaAwareProcessor();


    //! Checks for thrown exceptions
    /**
     *
     * @return bool - true when there is a pending exception; otherwise return false
    */
    bool exceptionOccurred();

    //! Clears any exception that is currently being thrown. If no exception is currently being thrown, this routine has no effect.
    void exceptionClear();


    //! Utility method for working with SaxonC on Python
    XdmValue ** createXdmValueArray(int len){
	   return (new XdmValue*[len]);
    }

    //! Utility method for working with SaxonC on Python
    XdmAtomicValue ** createXdmAtomicValueArray(int len){
	   return (new XdmAtomicValue*[len]);
    }

    //! Checks for pending exceptions and creates a SaxonApiException object, which handles one or more local exceptions objects
    /**
     *
     * @param env
     * @param callingClass
     * @param callingObject
    */
    static SaxonApiException *checkForExceptionCPP(JNIEnv *env, jclass callingClass, jobject callingObject);

    //! Clean up and destroy Java VM to release memory used. Method to be called at the end of the program
    static void release();

    //! Attaches a current thread to the a Java VM
    static void attachCurrentThread();

    //! Detach JVM from the current thread
    static void detachCurrentThread();


    //! Set the current working directory
    void setcwd(const char *cwd);

    //! Get the current working directory
    /**
     *
     * @return string value of the cwd
    */
    const char *getcwd();


    //! Get saxon resources directory
    /**
     *
     * @return string value of the resource directory
    */
   const char * getResourcesDirectory();


    //! set saxon resources directory
   void setResourcesDirectory(const char* dir);

    /**
     * set catalog to be used in Saxon
    */
    void setCatalog(const char *catalogFile, bool isTracing);


    //! Set a configuration property specific to the processor in use.
    /**
     *
     * Properties specified here are common across all the processors.
     * Example 'l':enable line number has the value 'on' or 'off'
     * @param name of the property
     * @param value of the property
     */
    void setConfigurationProperty(const char *name, const char *value);

    //! Clear configuration properties specific to the processor in use.
    void clearConfigurationProperties();


    //! Get the Saxon version
    /**
     *
     * @return char array
     */
    const char *version();

    //! Add a native method.
    /**
     *
     * @param name of the native method
     * @param signature of the native method
     * @param fnPtr Pointer to the native method
    */
    void addNativeMethod(char *name, char *signature, void *fnPtr) {

        JNINativeMethod method;
        method.name = name;
        method.signature = signature;
        method.fnPtr = fnPtr;

        nativeMethodVect.push_back(method);


    }

    //! Register several native methods for one class.
    /**
     *
     * @param libName name of the library which contains the function(s). Loads the library
     * @param gMethods Register native methods. Default is nullptr, also nullptr allowed in
     which cause assumption is made the user has added native methods using the method addNativeMethod .
    * @return bool success of registered native method
    */
    bool registerCPPFunction(char *libName, JNINativeMethod *gMethods = nullptr) {
        if (libName != nullptr) {
            setConfigurationProperty("extc", libName);

        }

        if (gMethods == nullptr && nativeMethodVect.size() == 0) {
            return false;
        } else {
            if (gMethods == nullptr) {
                //copy vector to gMethods
                gMethods = new JNINativeMethod[nativeMethodVect.size()];
            }
            return registerNativeMethods(sxn_environ->env, "com/saxonica/functions/extfn/CppCall$PhpFunctionCall",
                                         gMethods, nativeMethodVect.size());


        }
        return false;
    }

    //! Register several native methods for one class.
    /**
    * @param env
     * @param className
     * @param gMethods
     * @param numMethods
    * @return bool success of registered native method
    */
    static bool registerNativeMethods(JNIEnv *env, const char *className,
                                      JNINativeMethod *gMethods, int numMethods) {
        jclass clazz;
        clazz = env->FindClass(className);
        if (clazz == nullptr) {
            std::cerr << "Native registration unable to find class " << className << std::endl;
            return false;
        }

        if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
            // std::cerr<<"RegisterNatives failed for "<< className<<std::endl;
            return false;
        }
        return true;
    }

    //! Check for exception thrown in the underlying JNI. Then create the SaxonApiException class which the user can retrieve
    /**
     *
     * @param cppClass
     * @return The SaxonApiException with information about the exception thrown
     */
    SaxonApiException *checkAndCreateException(jclass cppClass);




    static int jvmCreatedCPP; /*!< Flag to indicate jvm created - used in memory management */
    static sxnc_environment *sxn_environ;/*!< Environment to captures the jni, JVM and handler to the cross compiled SaxonC library. */
    std::string cwd; /*!< current working directory */
    jobject proc; /*!< Java Processor object */


/**
 * Get info on objects allocated and still in memory
 */
    static void getInfo();

    /*static JavaVM *jvm;*/

protected:


    jclass xdmAtomicClass; /*!< The XdmAtomicValue instance */
    jclass versionClass; /*!< The Version instance */
    jclass procClass; /*!< The SAxon Processor instance */
    jclass saxonCAPIClass; /*!< The SaxonCAPI instance */
    std::string cwdV; /*!< current working directory */
    //std::string resources_dir; /*!< current Saxon resources directory */
    std::string versionStr; /*!< The Saxon version string */
    std::map<std::string, XdmValue *> parameters; /*!< map of parameters used for the transformation as (string, value) pairs */
    std::map<std::string, std::string> configProperties; /*!< map of properties used for the transformation as (string, string) pairs */
    bool licensei; /*!< indicates whether the Processor requires a Saxon that needs a license file (i.e. Saxon-EE) other a Saxon-HE Processor is created  */


    JNINativeMethod *nativeMethods; /*!< native methods variable used in extension methods */
    std::vector<JNINativeMethod> nativeMethodVect; /*!< Vector of native methods defined by user */
    SaxonApiException *exception; /*!< SaxonApiException object to capture exceptions thrown from the underlying Java code via JNI */


private:

    void createException(const char * message=nullptr);

    void initialize(bool l);

    void applyConfigurationProperties();

    // SaxonC method for internal use
    static JParameters
    createParameterJArray(std::map<std::string, XdmValue *> parameters, std::map<std::string, std::string> properties, int additions = 0);

    static JParameters createParameterJArray2(std::map<std::string, XdmValue *> parameters);

    static jobjectArray createJArray(XdmValue **values, int length);

    static const char *checkException();
};


//===============================================================================================



#endif /* SAXON_PROCESSOR_H */
