See SaxonC documentation for full guide on installing SaxonC python extension:

https://www.saxonica.com/saxon-c/documentation/index.html#!starting/installingpython

python3 saxon-setup.py build_ext -if

pydoc3 -w saxonc

Run pytest-3:

pytest-3 test_saxonc.py
